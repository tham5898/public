import React, { Component } from 'react'

export default class UpdateData extends Component {

    state = {

        FristName: this.props.dataUpdate.name.first,
        LastName: this.props.dataUpdate.name.last,
        Gender: this.props.dataUpdate.gender,
        Street: this._getStreet(this.props),
        Email: this.props.dataUpdate.email,
        Phone: this.props.dataUpdate.phone
    }

    _getStreet(props) {
        const location = props.dataUpdate.location;
        let street = "";
        if (location) {
            street = location.street;
        }
        return street;
    }

    componentDidMount() {
        console.log(this.state.dataUpdate);

    }
    handleChange = (e) => {
        this.setState({ [e.target.name]: e.target.value })
    }
    onClickUpdate = () => {
        // de ham render dc goi sau khi nhap vao nut edit
        this.setState({ ...this.state.personRecord })

    }
    render() {

        return (
            <div className='container'>

                <button type="button"
                    onClick={() => {
                        this.onClickUpdate()
                    }} class="btn btn-success" data-toggle="modal" data-target="#exampleModalData" data-whatever="@mdo">Edit</button>
                <div class="modal fade" id="exampleModalData" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalData">Edit data</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                    <div class='form-group'>
                                        <label for="recipient-name" class="col-form-label">Frist Name:</label>
                                        <input value={this.state.FristName} type="text" name="FristName" class="form-control" id="recipient-name" onChange={this.handleChange}></input>
                                    </div>

                                    <div class='form-group'>
                                        <label for="recipient-name" class="col-form-label">Last Name:</label>
                                        <input value={this.state.LastName} type="text" name="LastName" class="form-control" id="recipient-name" onChange={this.handleChange}></input>
                                    </div>
                                    <div class='form-group'>
                                        <label for="recipient-name" class="col-form-label">Gender:</label>
                                        <input value={this.state.Gender} type="text" name="Gender" class="form-control" id="recipient-name" onChange={this.handleChange}></input>
                                    </div>
                                    <div class='form-group'>
                                        <label for="recipient-name" class="col-form-label">Street:</label>
                                        <input value={this.state.Street} type="text" name="Street" class="form-control" id="recipient-name" onChange={this.handleChange}></input>
                                    </div>
                                    <div class='form-group'>
                                        <label for="recipient-name" class="col-form-label">Email:</label>
                                        <input value={this.state.Email} type="text" name="Email" class="form-control" id="recipient-name" onChange={this.handleChange}></input>
                                    </div>
                                    <div class='form-group'>
                                        <label for="recipient-name" class="col-form-label">Phone:</label>
                                        <input value={this.state.Phone} type="number" name="Phone" class="form-control" id="recipient-name" onChange={this.handleChange}></input>
                                    </div>

                                </form>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary" onClick={this.onClickUpdate}>Save changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
