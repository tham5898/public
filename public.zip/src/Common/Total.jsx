import React, { Component } from 'react'

export default class Total extends Component {
    
    render() {
        return (
            <div>
                <span>{this.props.Total}</span>
            </div>
        )
    }
}
