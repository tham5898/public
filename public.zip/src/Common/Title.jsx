import React, { PureComponent } from 'react';

export default class Title extends PureComponent {
    render() {
        return (
          <p className="text-center" style={{fontSize:50, }}> Trang quản lý điện thoại</p>
        )
    }
}
