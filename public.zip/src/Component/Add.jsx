import React, { PureComponent } from 'react'
// import './bootstrap.min.css';
import './style.css';
export default class Add extends PureComponent {
    render() {
        return (
           <div className="Title"> Quản lý công việc </div>
        )
    }
}
