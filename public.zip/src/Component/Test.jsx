import React, { PureComponent } from 'react'
import Add from './Add';

export default class Test extends PureComponent {
    render() {
        return (
          <Add/> 
        )
    }
}
